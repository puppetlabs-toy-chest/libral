module CRubyExtension
  def CRubyExtension.ruby_method
    puts "A Ruby Extension"
  end
end
